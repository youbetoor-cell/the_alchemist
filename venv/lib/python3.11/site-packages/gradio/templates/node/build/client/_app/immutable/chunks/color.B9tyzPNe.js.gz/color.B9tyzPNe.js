import{r}from"./2.CDVdg6R9.js";const t=o=>r[o%r.length];export{t as g};
//# sourceMappingURL=color.B9tyzPNe.js.map
