import{U as a,C as n}from"./mermaid.core.Bp-ISXuX.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.CO0wSnDg.js.map
