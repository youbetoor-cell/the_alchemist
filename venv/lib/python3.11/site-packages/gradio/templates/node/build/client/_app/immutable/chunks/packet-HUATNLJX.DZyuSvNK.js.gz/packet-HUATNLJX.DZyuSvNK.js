import{P as c,a as r}from"./mermaid-parser.core.B53d7pJN.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.DZyuSvNK.js.map
